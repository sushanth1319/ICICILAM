package stepDefinitions;

import helper.JavaScriptHelper;
import io.appium.java_client.AppiumBy;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.AndroidMobileCapabilityType;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.eclipse.jetty.util.security.Password;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import pageObjects.Base_PO;
import pageObjects.Zions_Bank_PO;

import java.util.HashMap;

public class Zion_bank_SD extends Base_PO {
    private Zions_Bank_PO zions_bank_po;
    private JavaScriptHelper scroll_to_element;
    public Zion_bank_SD(Zions_Bank_PO zions_bank_po,JavaScriptHelper scroll_to_element){
        this.zions_bank_po=zions_bank_po;
        this.scroll_to_element=scroll_to_element;
    }
    @Given("the user is on the ZIONS Bank Mobile Banking Login page")
    public void theUserIsOnTheZIONSBankMobileBankingLoginPage() {


    }

    @When("the user clicks on Personal tab")
    public void theUserClicksOnPersonalTab() {
        zions_bank_po.Personal_Tab();

    }

    @And("the user inputs the invalid Username{string}")
    public void theUserInputsTheInvalidUsername(String User_name) {
        zions_bank_po.User_Name(User_name);
    }

    @And("the user inputs the invalid password{string}")
    public void theUserInputsTheInvalidPassword(String password) {
        zions_bank_po.Password(password);
    }

    @And("the user clicks the Sign In button")
    public void theUserClicksTheSignInButton() {
        zions_bank_po.Sign_In();
    }

    @Then("the user should not be Authenticated")
    public void theUserShouldNotBeAuthenticated() {
    }
    @And("the error message should be displayed as {string}")
    public void theErrorMessageShouldBeDisplayedAs(String expectedError) {
        zions_bank_po.Error_Message(expectedError);

    }
////////////////////////test-case2/////////////////////////////////////////////////
    @And("the user clicks on Save Personal Username radio button")
    public void theUserClicksOnSavePersonalUsernameRadioButton() {
        zions_bank_po.Save_User_Name();
        
    }

    @When("the user redirect to ZIONS Bank login page")
    public void theUserRedirectToZIONSBankLoginPage() {
        zions_bank_po.Ok();

    }

    @Then("the user is able to see the recently entered invalid username saved in Username text box")
    public void theUserIsAbleToSeeTheRecentlyEnteredInvalidUsernameSavedInUsernameTextBox() {

    }
////////////////////////////////////////////////////////////////
    @And("the user clicks on Forgot Username")
    public void theUserClicksOnForgotUsername() {

    }

    @And("the user redirected to Forgot Username page")
    public void theUserRedirectedToForgotUsernamePage() {
    }

    @And("the user enters last {int} digit of {string}")
    public void theUserEntersLastDigitOf(int arg0, String arg1) {
    }

    @And("the user enters {string}")
    public void theUserEnters(String arg0) {
    }

    @And("the user clicks on Continue")
    public void theUserClicksOnContinue() {
    }

    @And("the user clicks on Get Username")
    public void theUserClicksOnGetUsername() {
    }

    @Then("the user is able to see the valid username details")
    public void theUserIsAbleToSeeTheValidUsernameDetails() {
    }
////////////////////more_validation///////////////////////////////////
    @And("the user clicks on More button")
    public void theUserClicksOnMoreButton() {
        zions_bank_po.More();
    }

    @Then("the user redirected to More page")
    public void theUserRedirectedToMorePage() {
    }

    @And("the user is able to see Apply for a Checking Account option{string}")
    public void theUserIsAbleToSeeApplyForACheckingAccountOption(String Expected_value_check_account) {
        zions_bank_po.Check_account(Expected_value_check_account);

    }

    @And("the user is able to see Apply for a Savings Account option{string}")
    public void theUserIsAbleToSeeApplyForASavingsAccountOption(String Expected_value_savings_account) {
        zions_bank_po.Savings_account(Expected_value_savings_account);
    }

    @And("the user is able to see Apply for a Credit Card option{string}")
    public void theUserIsAbleToSeeApplyForACreditCardOption(String Expected_value_credit_card) {
        zions_bank_po.Credit_Card(Expected_value_credit_card);
    }

    @And("the user is able to see Financial Calculators option FINANCIAL CALCULATORS")
    public void theUserIsAbleToSeeFinancialCalculatorsOption() {
        zions_bank_po.Calculator();
    }

    @And("the user is able to see Privacy & Terms option{string}")
    public void theUserIsAbleToSeePrivacyTermsOption(String Expected_Privacy) {
        zions_bank_po.Privacy(Expected_Privacy);
    }

    @When("the user clicks on  Apply for a Checking Account option")
    public void theUserClicksOnApplyForACheckingAccountOption() {
        zions_bank_po.Apply_for_checking_account();

    }

    @Then("the user should redirect to Personal Checking page")
    public void theUserShouldRedirectToPersonalCheckingPage() {
    }

    @When("the user clicks on Compare Products button")
    public void theUserClicksOnCompareProductsButton() throws InterruptedException {
          Thread.sleep(7000);
        getDriver().findElement(AppiumBy.androidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textContains(\"COMPARE PRODUCTS\").instance(0))")).click();
    }

    @Then("the user should redirect to {string} page")
    public void theUserShouldRedirectToPage(String Compare_checking_accounts) {
        zions_bank_po.Compare_Checking_accounts(Compare_checking_accounts);
    }


    @And("the user is able to see Cancel button at the bottom{string}")
    public void theUserIsAbleToSeeCancelButtonAtTheBottom() {

    }
    ////////////////contact_test_case/////////////

    @And("the user clicks on Contact us button")
    public void theUserClicksOnButton() {
        zions_bank_po.Contact_Us();
    }

    @Then("the user redirected to Contact us page")
    public void theUserRedirectedToContactUsPage() {
    }

    @And("the user is able to see the Contact number details of the near by branches")
    public void theUserIsAbleToSeeTheContactNumberDetailsOfTheNearByBranches() {
        zions_bank_po.isDisplayed_Contact_page_elements();
    }

    @And("the user is able to see the Working hours details of the branches")
    public void theUserIsAbleToSeeTheWorkingHoursDetailsOfTheBranches() {
        zions_bank_po.isDisplayed_Contact_page_elements();
    }

    @And("the user clicks on Forgot Password")
    public void theUserClicksOnForgotPassword() {
        zions_bank_po.Forgot_password();
    }

    @And("the user redirected to Forgot Password page")
    public void theUserRedirectedToForgotPasswordPage() {
    }

    @And("the user enters invalid Username in username text box")
    public void theUserEntersInvalidInUsernameTextBox() throws InterruptedException {

            zions_bank_po.Forgot_Username();
    }

    @And("the user enters invalid email address in Email Address or Phone Number text box")
    public void theUserEntersInvalidEmailAddressInTextBox() {
        zions_bank_po.Forgot_Gmail();
    }

    @And("the user clicks on Submit button")
    public void theUserClicksOnSubmitButton() {
        zions_bank_po.Captcha();
        getDriver().findElement(AppiumBy.androidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textContains(\"SUBMIT\").instance(0))")).click();

    }


    @Then("the user receives error message as {string}")
    public void theUserReceivesErrorMessageAs(String arg0) {
    }

    @When("the user clicks on Select Product to compare button")
    public void theUserClicksOnSelectProductToCompareButton() {

        getDriver().findElement(AppiumBy.androidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textContains(\"SELECT PRODUCTS TO COMPARE\").instance(0))")).click();
    }

    @And("the user should be able to see ANYTIME CHECKING product")
    public void theUserShouldBeAbleToSeeANYTIMECHECKINGProduct() {
        zions_bank_po.Products();
    }

    @And("the user should be able to see ANYTIME INTEREST CHECKING product")
    public void theUserShouldBeAbleToSeeANYTIMEINTERESTCHECKINGProduct() {
        zions_bank_po.Products();
    }

    @And("the user should be able to see MILITARY ADVANTAGE CHECKING product")
    public void theUserShouldBeAbleToSeeMILITARYADVANTAGECHECKINGProduct() {
        zions_bank_po.Products();
    }

    @And("the user should be able to see PREMIUM INTEREST CHECKING product")
    public void theUserShouldBeAbleToSeePREMIUMINTERESTCHECKINGProduct() {
        zions_bank_po.Products();
    }

    @And("the user should be able to see ONBUDGET BANKING product")
    public void theUserShouldBeAbleToSeeONBUDGETBANKINGProduct() {
        zions_bank_po.Products();
    }

    @And("the user selects any three products from the above prodcut list")
    public void theUserSelectsAnyProductsFromTheAboveProdcutList() {
        zions_bank_po.Product_Selection();
    }

    @Then("the user should get a pop up alert message You can compare maximum three products at a time. Please adjust the selection accordingly")
    public void theUserShouldGetAPopUpAlertMessageYouCanCompareMaximumThreeProductsAtATimePleaseAdjustTheSelectionAccordingly() {

    }

    @And("the user should be able to see Compare and Hide buttons")
    public void theUserShouldBeAbleToSeeCompareAndHideButtons() {
    }

    @When("the user remains idle and don't take any action for three seconds")
    public void theUserRemainsIdleAndDonTTakeAnyActionForSeconds() {
    }

    @Then("the pop up alert message window should close automatically")
    public void thePopUpAlertMessageWindowShouldCloseAutomatically() {
    }
    ///////////////////////////////////////////////////////////////////////////////////////////////

    @When("the user clicks on Compare button")
    public void theUserClicksOnCompareButton() throws InterruptedException {
        Thread.sleep(3000);
       zions_bank_po.Compare_3_products();

    }

    @Then("the user redirected to Compare Products screen with the selected three products")
    public void theUserRedirectedToScreenWithTheSelectedProducts() {

    }

    @And("the user should be able to see one,two and three numbers in circle")
    public void theUserShouldBeAbleToSeeAndNumbersInCircle() {
        zions_bank_po.Circles_Display();
    }

    @And("the user should be able to see backward  \\(< )and forward \\( > ) arrows")
    public void theUserShouldBeAbleToSeeBackwardAndForwardArrows() {
    }

    @When("the user clicks on three number")
    public void theUserClicksOnNumber() {
        zions_bank_po.Circle3_Click();
    }

    @Then("the user should be able to see the comparison between second and third product")
    public void theUserShouldBeAbleToSeeTheComparisonBetweenNdAndRdProduct() {

    }

    @When("the user clicks on backward \\( < ) arrow")
    public void theUserClicksOnBackwardArrow() {
        zions_bank_po.Circle2_Click();
        zions_bank_po.Circle1_Click();
    }

    @Then("the user should be able to see first and second product comparison")
    public void theUserShouldBeAbleToSeeStAndNdProductComparison() {
    }

    @And("the user scroll down")
    public void theUserScrollDown() {
        //getDriver().findElement(AppiumBy.androidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textContains(\"None\").instance(0))"));
    }

    @And("the user should be able to see the complete list of comparison details")
    public void theUserShouldBeAbleToSeeTheCompleteListOfComparisonDetails() {
    }

    @When("the user clicks on number two mentioned on top of eStatements word under Paper Statement Service field")
    public void theUserClicksOnNumberMentionedOnTopOfWordUnderField() {
        zions_bank_po.Circle1_Click();
        getDriver().findElement(AppiumBy.androidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textContains(\"Paper Statement Service\").instance(0))")).click();

        zions_bank_po.Circle_paper_statement();
    }

    @Then("the pop up alert message window with {string} title should appear")
    public void thePopUpAlertMessageWindowWithTitleShouldAppear(String Pop_up) {
//        zions_bank_po.Important_Popup(Pop_up);
    }

    @When("the user clicks on the close \\( X ) button")
    public void theUserClicksOnTheCloseXButton() {
        zions_bank_po.Important_Popup_close();
    }

    @Then("the user should redirected back to the product comparison screen")
    public void theUserShouldRedirectedBackToTheProductComparisonScreen() {
    }

    @When("the user scroll up")
    public void theUserScrollUp() {
    }

    @Then("the user should go back to the Compare checking account screen")
    public void theUserShouldGoBackToTheCompareCheckingAccountScreen() {
        getDriver().findElement(AppiumBy.androidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textContains(\"COMPARE CHECKING ACCOUNTS\").instance(0))"));

    }

    @When("the user clicks on close \\( X ) button")
    public void theUserClicksOnCloseXButton() {
        zions_bank_po.Exit_From_Compare();
    }

    @Then("the user redirected to  {string} screen")
    public void theUserRedirectedToScreen(String arg0) {
    }
    /////////////////////////////////////////////////////////////////////////////////////////////////

    @And("the user reach to the bottom of product comparison screen")
    public void theUserReachToTheBottomOfProductComparisonScreen() {
        getDriver().findElement(AppiumBy.androidUIAutomator("new UiScrollable(new UiSelector().scrollable(true).instance(0)).scrollIntoView(new UiSelector().textContains(\"Incoming Domestic Wire Transfer fee waivers\").instance(0))"));

    }

    @When("the user clicks on Up Arrow button")
    public void theUserClicksOnUpArrowButton() {
        zions_bank_po.Up_button();
    }

    @Then("the user should go to the top of the Compare checking account screen")
    public void theUserShouldGoToTheTopOfTheCompareCheckingAccountScreen() {

    }
    ///////////////////////////////////////////////////////////////


    ///////////////////////////////////////////////////////////////////////////////////

}
