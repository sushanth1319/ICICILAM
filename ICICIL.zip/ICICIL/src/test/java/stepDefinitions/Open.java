package stepDefinitions;

import io.cucumber.java.en.Given;
import pageObjects.Base_PO;

public class Open extends Base_PO{

@Given("open the chrome navigate")
public void open_the_chrome_navigate() {
getDriver().get("https://www.amazon.com");

    // Write code here that turns the phrase above into concrete actions

}

}
