package stepDefinitions;

import java.io.IOException;
//import java.net.MalformedURLException;

//import org.apache.commons.mail.EmailException;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjects.Base_PO;
import pageObjects.ICICI_PO;

public class ICICISteps extends Base_PO {
	private ICICI_PO icici_po;
	
	public ICICISteps(ICICI_PO icici_po) {
		this.icici_po = icici_po;
	}
	@Given("user starts the browser")
	public void user_starts_the_browser() {
		navigateTo_URL("http://127.0.0.1:8083/VersionRepo.PLIPLNIPLABusinessRMA/index.html");
	}

	@When("user enters username and password")
	public void user_enters_username_and_password() {
	    icici_po.Username1();
	    icici_po.Pasword1();
	}

	@Then("user clicks login")
	public void user_clicks_login() throws InterruptedException {
	    icici_po.Login1();
		
	}

	@When("user selects the {string}")
	public void user_selects_the_product(String product) throws InterruptedException{
		
		icici_po.select_Product(product);
	}

	@When("user click on update and refresh and complie")
	public void user_click_on_update_and_refresh_and_complie() throws  InterruptedException  {
	   icici_po.update_refresh_compile1();
	}

	  

	@Then("user clicks on generate ADB and send {string}and{string}")
	public void user_clicks_on_generate_adb_and_send_fileName_and_serverFile(String fileName,String serverFile ) throws InterruptedException,IOException {
	 icici_po.generate_ADB(fileName,serverFile);
	}

	@Then("user clicks Logoff")
	public void user_clicks_logoff() {
		icici_po.logoff2();
		
}
}
