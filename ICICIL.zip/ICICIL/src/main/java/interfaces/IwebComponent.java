package interfaces;


public interface IwebComponent {

}