package utils;

public class Constants {
    public static final boolean IS_PARALLEL = TestRunConfig.IS_PARALLEL;

}
