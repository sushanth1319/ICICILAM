package utils;

import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import model.Policy;

@Setter
@Getter
@ToString
public class TestContext {
    private Policy policy;

}
