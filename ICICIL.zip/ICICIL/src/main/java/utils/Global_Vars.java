package utils;

public class Global_Vars {
    public static final int DEFAULT_EXPLICIT_TIMEOUT = 1000;
    
    public static final int DEFAULT_EXPLICIT_TIMEOUT_Min = 600000;

    public static final String WEBDRIVER_UNIVERSITY_HOMEPAGE_URL =  "http://10.10.10.91:8180/pc/PolicyCenter.do";
}
