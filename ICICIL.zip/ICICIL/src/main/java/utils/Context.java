package utils;
public enum Context {
	AffinityBusinessRMA,EmigrantTravelBusiness_RMA,FireIPartnerBusiness_RMA,ComprehensiveRiskProtect_BusinessRMA;
}
//String productName = productListingPage.getProductName(0); 
//testContext.scenarioContext.setContext(Context.PRODUCT_NAME, productName);
//ScenarioContext productName = testContext.getScenarioContext();
//testContext.scenarioContext.setContext(Context.AffinityBusinessRMA, productName);