package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class lombard extends Base_PO {
	static WebDriver  driver;

	public static void main(String[] args) throws InterruptedException {
		              
		
		WebDriverManager.edgedriver().setup();
		
		driver = new EdgeDriver();
		driver.manage().window().maximize();
		driver.navigate().to("http://127.0.0.1:8083/VersionRepo.PLIPLNIPLABusinessRMA/index.html");
		Thread.sleep(2000);
		driver.findElement(By.id("elm_username")).sendKeys("admin");
		driver.findElement(By.id("elm_password")).sendKeys("admin");
		driver.findElement(By.id("default_btn_submit")).click();
		
		Thread.sleep(28000);
		driver.findElement(By.id("BOILERBusinessRMA")).click();
		Thread.sleep(1000);
		driver.findElement(By.id("6")).click();
		
		
		
		driver.close();
	

		
	}

}
