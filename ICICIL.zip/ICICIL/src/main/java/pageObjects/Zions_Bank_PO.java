package pageObjects;

import helper.CheckBoxOrRadioButtonHelper;
import helper.JavaScriptHelper;
import org.apache.commons.lang3.RandomStringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

public class Zions_Bank_PO extends Base_PO {
    private CheckBoxOrRadioButtonHelper checkBoxOrRadioButtonHelper;
    private JavaScriptHelper javascripthelper;

    // @FindBy(xpath = "\t/hierarchy/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ScrollView/android.view.ViewGroup/android.widget.LinearLayout[1]/androidx.viewpager.widget.ViewPager/android.widget.LinearLayout/android.widget.RelativeLayout[1]/android.widget.LinearLayout/android.widget.FrameLayout/android.widget.EditText")
    public Zions_Bank_PO(CheckBoxOrRadioButtonHelper checkBoxOrRadioButtonHelper, JavaScriptHelper javascripthelper) {
        this.checkBoxOrRadioButtonHelper = checkBoxOrRadioButtonHelper;
        this.javascripthelper = javascripthelper;
    }

    @FindBy(xpath = "//android.widget.EditText[@text='Enter Username']")
    public WebElement User_Name;
    @FindBy(xpath = "//android.widget.TextView[@text='Personal']")
    WebElement Personal_Tab;
    @FindBy(xpath = "//android.widget.EditText[@text='Enter Password']")
    WebElement Password;
    @FindBy(xpath = "//android.widget.Button[@text='Sign in']")
    WebElement Sign_In;
    @FindBy(xpath = "//android.widget.CheckBox[@text='Save Personal Username']")
    WebElement Save_user_name_and_password;
    @FindBy(xpath = "\t/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.FrameLayout/android.view.ViewGroup/android.widget.TextView")
    WebElement Error_Message;
    @FindBy(xpath = "//android.widget.CheckBox[@text='Save Personal Username']")
    WebElement Save_Username;
    @FindBy(xpath = "//android.widget.Button[@text='Ok']")
    WebElement Ok;
    @FindBy(xpath = "//android.widget.Button[@text='More']")
    WebElement More;
    @FindBy(xpath = "//android.widget.Button[@text='APPLY FOR A CHECKING ACCOUNT']")
    WebElement Apply_for_a_checking_account;
    @FindBy(xpath = "//android.widget.Button[@text='APPLY FOR A SAVINGS ACCOUNT']")
    WebElement Apply_for_a_savings_account;
    @FindBy(xpath = "//android.widget.Button[@text='APPLY FOR A CREDIT CARD']")
    WebElement Apply_for_a_credit_card;
    @FindBy(xpath = "//android.widget.Button[@text='FINANCIAL CALCULATORS']")
    WebElement Financial_calculators;
    @FindBy(xpath = "//android.widget.Button[@text='PRIVACY & TERMS']")
    WebElement Privacy_terms;
    @FindBy(xpath = "//android.widget.TextView[@text='COMPARE PRODUCTS']")
    public WebElement Compare_Products;

    @FindBy(xpath = "//android.widget.Button[@text='Contact Us']")
    WebElement Contact_Us;
    @FindBy(xpath = "//android.widget.TextView[@text='888-307-3411']")
    WebElement zions_bank_phone;
    @FindBy(xpath = "//android.widget.TextView[@text='Monday to Saturday from 6 a.m. to 9 p.m. MT.']")
    WebElement Working_Hours;
    @FindBy(xpath = "//android.widget.Button[@text='Forgot Password']")
    WebElement Forgot_password;
    @FindBy(xpath = "//android.widget.EditText[@resource-id='username']")
    WebElement Forgot_Username;
    @FindBy(xpath = "//android.widget.EditText[@resource-id='destination']")
    WebElement Forgot_Gmail;
    @FindBy(xpath = "//android.view.View[@resource-id='rc-anchor-container']")
    WebElement captcha;
    @FindBy(xpath = "//android.widget.Button[@text='SUBMIT']")
    WebElement Submit;
    @FindBy(xpath = "//android.widget.TextView[@text='COMPARE CHECKING ACCOUNTS']")
    WebElement Compare_Checking_Accounts;

    @FindBy(xpath = "//android.widget.TextView[@text='SELECT PRODUCTS TO COMPARE']")
    WebElement Select_Products_to_compare;
    @FindBy(xpath = "//android.widget.Button[@text='Compare']")
    WebElement Compare_Popup;
    @FindBy(xpath = "//android.widget.Button[@text='ANYTIME CHECKING®']")
    WebElement Product_1;
    @FindBy(xpath = "//android.widget.Button[@text='MILITARY ADVANTAGE CHECKING']")
    WebElement Product_2;
    @FindBy(xpath = "//android.widget.Button[@text='ANYTIME INTEREST CHECKING®']")
    WebElement Product_3;
    @FindBy(xpath = "//android.widget.Button[@text='PREMIUM INTEREST CHECKING']")
    WebElement Product_4;
    @FindBy(xpath="//android.widget.Button[@text='1']")
    WebElement Circle_1;
    @FindBy(xpath="//android.widget.Button[@text='2']")
    WebElement Circle_2;
    @FindBy(xpath="//android.widget.Button[@text='3']")
    WebElement Circle_3;
    @FindBy(xpath="//android.widget.TextView[@text='Paper Statement Service']")
    WebElement Paper_Statement;
    @FindBy(xpath="//android.widget.TextView[@text='2']")
    WebElement papaer_statement_service_field;
    @FindBy(xpath="//android.widget.TextView[@text='OTHER FEES AND SERVICE CHARGES']")
    WebElement Scroll_function;
    @FindBy(xpath="//android.widget.TextView[@text='Important Detail']")
    WebElement Important_detail_Popup;
    @FindBy(xpath="//android.view.View[@content-desc='Close']")
    WebElement Important_detail_Popup_close;
    @FindBy(xpath="//android.widget.Button[@text='COMPARE3']")
    WebElement Compare_3;
    @FindBy(xpath="//android.widget.ImageView[@content-desc='Done']")
    WebElement Exit_From_Compare_Screen;
    @FindBy(xpath="//android.widget.Button[@text='Back to Top']")
    WebElement Up_button;



    public void User_Name(String user_name) {
        user_name = RandomStringUtils.randomAlphanumeric(5);
        sendKeys(User_Name, user_name);
    }

    public void Personal_Tab() {
        waitForWebElementAndClick(Personal_Tab);
    }

    public void Password(String password) {
        password = RandomStringUtils.randomAlphanumeric(7);
        sendKeys(Password, password);
    }

    public void Sign_In() {
        waitForWebElementAndClick(Sign_In);

    }

    public void Save_user_name_and_password() {
        waitForWebElementAndClick(Save_user_name_and_password);
    }

    public void Error_Message(String Expected_value) {
        waitFor(Error_Message);
        String actual = getText(Error_Message);
        Assert.assertEquals(actual, Expected_value);
    }

    public void Save_User_Name() {
        checkBoxOrRadioButtonHelper.selectCheckBox(Save_Username);

    }

    public void Ok() {
        waitForWebElementAndClick(Ok);

    }

    public void More() {
        waitForWebElementAndClick(More);
    }

    public void Check_account(String Expected_value_check_account) {
        String Checking_account = getText(Apply_for_a_checking_account);
        Assert.assertEquals(Expected_value_check_account, Checking_account);
    }

    public void Savings_account(String Expected_value_savings_account) {
        String Savings_account = getText(Apply_for_a_savings_account);
        Assert.assertEquals(Savings_account, Expected_value_savings_account);
    }

    public void Credit_Card(String Expected_value_credit_card) {
        String Credit_card = getText(Apply_for_a_credit_card);
        Assert.assertEquals(Credit_card, Expected_value_credit_card);
    }

    public void Calculator() {
        Boolean Display1 = isDisplayed(Financial_calculators);

    }


    public void Privacy(String Expected_Privacy) {
        String Privacy = getText(Privacy_terms);
        Assert.assertEquals(Expected_Privacy, Privacy);
    }

    public void Apply_for_checking_account() {
        waitForWebElementAndClick(Apply_for_a_checking_account);
    }

    public WebElement Compare_products() {
        waitForWebElementAndClick(Compare_Products);
        return Compare_Products;
    }

    public void Compare_Checking_accounts(String Compare_checking_accounts) {
        String Compare = getText(Compare_Checking_Accounts);
        Assert.assertEquals(Compare, Compare_checking_accounts);
    }

    public void isDisplayed() {

        Boolean Displayed = isDisplayed(Apply_for_a_checking_account);
        Boolean Displayed2 = isDisplayed(Apply_for_a_savings_account);
        Boolean Displayed3 = isDisplayed(Apply_for_a_credit_card);
        Boolean Displayed4 = isDisplayed(Privacy_terms);
        System.out.print(Displayed);
        System.out.println();


    }

    public void Contact_Us() {
        waitForWebElementAndClick(Contact_Us);
    }

    public void isDisplayed_Contact_page_elements() {
        Boolean Displayed = isDisplayed(zions_bank_phone);
        Boolean Displayed_work_hours = isDisplayed(Working_Hours);
    }

    public void Forgot_password() {
        waitForWebElementAndClick(Forgot_password);
    }

    public void Forgot_Username() {
        try {
            String Forgot_User_name = RandomStringUtils.randomAlphanumeric(5);
            sendKeys(Forgot_Username,Forgot_User_name);
        }
        catch(StaleElementReferenceException e){
            String Forgot_User_name = RandomStringUtils.randomAlphanumeric(5);
            sendKeys(Forgot_Username,Forgot_User_name);
        }
    }

    public void Forgot_Gmail() {
        String Forgot_Gmail1 = RandomStringUtils.randomAlphabetic(6);
        String Gmail = Forgot_Gmail1 +"@gmail.com";
        sendKeys(Forgot_Gmail, Gmail);
    }

    public void Submit() {
        waitForWebElementAndClick(Submit);
    }

    public void Captcha() {
        waitForWebElementAndClick(captcha);
    }


/////////////////////////////////////////////////////////////////////////////


    public void Select_products_Compare() {
        waitForWebElementAndClick(Select_Products_to_compare);

    }
    public void Compare_3_products(){
        waitForWebElementAndClick(Compare_3);

    }
    public void Products(){
        Boolean Display1=isDisplayed(Product_1);
        Boolean Dispaly2=isDisplayed(Product_2);
        Boolean Display3=isDisplayed(Product_3);
        Boolean Dispaly4=isDisplayed(Product_4);
    }
    public void Product_Selection(){
        waitForWebElementAndClick(Product_1);
        waitForWebElementAndClick(Product_2);
        waitForWebElementAndClick(Product_3);
    }
    public void Compare_Popup(){
        Boolean Display=isDisplayed(Compare_Popup);


    }
    public void Compare_Popup_click(){
        waitForWebElementAndClick(Compare_Popup);
    }
    public void Circles_Display(){
        Boolean Display1=isDisplayed(Circle_1);
        Boolean Dispaly2=isDisplayed(Circle_2);
        Boolean Dispaly3=isDisplayed(Circle_3);
    }
    public void Circle3_Click(){
        waitForWebElementAndClick(Circle_3);
    }
    public void Circle2_Click(){
        waitForWebElementAndClick(Circle_2);
    }
    public void Circle1_Click(){
        waitForWebElementAndClick(Circle_1);
    }
    public void Circle_paper_statement(){
        waitForWebElementAndClick(papaer_statement_service_field);
    }
    public void Scroll_down(){

    }
    public void Important_Popup(String Pop_up){
        String Popup=getText(Important_detail_Popup);
        Assert.assertEquals(Popup,Pop_up);

    }
    public void Important_Popup_close(){
        waitForWebElementAndClick(Important_detail_Popup_close);
    }
public void Exit_From_Compare(){
        waitForWebElementAndClick(Exit_From_Compare_Screen);
}
public void Up_button(){
        waitForWebElementAndClick(Up_button);
}


}