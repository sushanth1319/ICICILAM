//package pageObjects;
//import java.net.MalformedURLException;
//import org.apache.commons.mail.DefaultAuthenticator;
//import org.apache.commons.mail.EmailAttachment;
//import org.apache.commons.mail.EmailException;
//import org.apache.commons.mail.MultiPartEmail;
//
//public class extentReports {
//	 
//	//public static void main(String[] args) throws EmailException {
// 
//	public void mail() throws MalformedURLException, EmailException {
//		
//		// Create the attachment
//		  EmailAttachment attachment = new EmailAttachment();
//		  attachment.setPath("C:\\Users\\SushanthMerugu\\OneDrive - ValueMomentum, Inc\\Documents\\ICICILombard\\ICICILombardProject\\ICICIL\\Reports\\SparkReport 25-Mar-23 22-57-08\\Reports\\Spark.html");
//		  attachment.setDisposition(EmailAttachment.ATTACHMENT);
//		  attachment.setDescription("Extent Report");
//		  attachment.setName("Report");
//
//		  // Create the email message
//		  MultiPartEmail email = new MultiPartEmail();
//		  email.setHostName("smtp.gmail.com");
//			email.setSmtpPort(465);
//			email.setAuthenticator(new DefaultAuthenticator("sushanth.merugu13@gmail.com", "togr hrka lbuo rzog"));
//			email.setSSLOnConnect(true);
//			email.setFrom("seleniumbynaresh@gmail.com");
//			email.setSubject("Automated E-mail");
//			email.setMsg("This is an automated e-mail  ... :-)");
//			email.addTo("sushanth.merugu23@gmail.com");
//
//		  // add the attachment
//		  email.attach(attachment);
// 
//		  // send the email
//		  email.send();
//
//	}
//
//}
