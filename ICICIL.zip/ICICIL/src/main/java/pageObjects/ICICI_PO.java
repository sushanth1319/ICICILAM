package pageObjects;

import java.io.IOException;
import java.time.Duration;
//import java.net.MalformedURLException;
import java.util.List;

//import org.apache.commons.mail.EmailException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import driver.DriverFactory;

public class ICICI_PO extends Base_PO {
	public ICICIUtils utils;
//	private EmailGenerated mail_trigger1;
	
	
//	public ICICI_PO(ICICIUtils utils,EmailGenerated mail_trigger1) {
//		this.utils = utils;
//		this.mail_trigger1 = mail_trigger1;
//	}
	public ICICI_PO(ICICIUtils utils) {
		this.utils = utils;
	}


	//	public ICICI_PO(extentReports mail_trigger1) {
//		this.mail_trigger1 = mail_trigger1;
//	}
	@FindBy(xpath = "//*[@id='elm_username']")
	WebElement uname;

	@FindBy(xpath = "//*[@id='elm_password']")
	WebElement pword;

	@FindBy(xpath = "//*[@id='default_btn_submit']")
	WebElement submit;
	
//	@FindBy(id = "AffinityBusinessRMA")
//	WebElement Corporate;
	
	@FindBy(xpath = "//div[@title=' Update']")
	public WebElement update;

	@FindBy(xpath= "//div[@title=' Refresh project']")
	WebElement refresh; 

	@FindBy(xpath = "//div[@title=' Compile']")
	WebElement compile;
	@FindBy(xpath = "//*[@id='loadingDiv']/img")
	List <WebElement> loadingIcon;
	
	@FindBy(xpath = "//div[@id='quick-verification-component']/div[3]")
	WebElement text;
	@FindBy(id = "quick-verification-component")
	WebElement text1;
	
	
	@FindBy(xpath = "//div[@id='working_projects_list']/div/a")
	List<WebElement> list;
	
	@FindBy(xpath ="//*[@id='global_signout']")
	WebElement logoff1;
	
	public void Username1() {
		sendKeys(uname, "admin");
	}
	public void Pasword1() {
		sendKeys(pword, "admin");
	}
	public void Login1() throws InterruptedException {
		waitForWebElementAndClick(submit);
		waitForLoadingIconDisappears();
	}
//	public void select_Product() {
//		waitForWebElementAndClick(Corporate);
//	}
	public void waitForLoadingIconDisappears() throws InterruptedException {

		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(70));
	}
	public void select_Product(String lnkProductName) throws InterruptedException{
 		String product = "//*[@id='working_projects_list']";
		WebElement productName = getDriver().findElement(By.xpath(product.replace("working_projects_list", lnkProductName)));	
		
		waitForWebElementAndClick(productName);
	}
	public void update_refresh_compile1() throws InterruptedException {
		waitForWebElementAndClick(update);
		for (int i = 1; i <= 120; i++) {	
			int av = DriverFactory.getDriver().findElements(By.xpath("//iframe[@class='yui-overlay-iframe']")).size();
			if (av != 0) {
//				getDriver().manage().timeouts().wait(5000);
				Thread.sleep(5000);
				System.out.println(i+"th iteration and Size of iFrame "+ av);
			} else {
				break;
			}
		}
		clickRefresh1();
		Thread.sleep(2000);
		clickCompile1();
}
	public void clickRefresh1(){
		waitForWebElementAndClick(refresh);
	}
	public void clickCompile1(){
		waitForWebElementAndClick(compile);
		
	}
	public void generate_ADB(String fileName ,String serverFile) throws InterruptedException,IOException {
		
		String[] Error_message = text.getText().split("with");
		//if(Arrays.asList(Error_message).contains("Success"));
		String m = Error_message[1];
		String[] q = m.split("error");
		String w = q[0].trim();
		System.out.println(w);
		if(w.contains("no")) {
			utils.ADB1();
			utils.label(fileName,serverFile);
			utils.Path1();
			utils.close1();
			utils.home1();
		}
		else {
		int error = Integer.parseInt(w);
		if (error > 0) {
			System.out.println("Errors");
			utils.home1();
			//mail_trigger1.mail();
		} else {
			utils.ADB1();
			utils.label(fileName,serverFile);
			utils.Path1();
			utils.close1();
			utils.home1();
		}
	}
}
	public void logoff2() {
		waitForWebElementAndClick(logoff1);
		DriverFactory.cleanupDriver();
	}
}

//int count =0;
//while(loadingIcon.isDisplayed() && count<20) {
//	Thread.sleep(2000);
//	count++;
//	System.out.println(count);
//}
//for(int i=1;i<20;i++) {
//	int size = loadingIcon.size();
//	if(i==1 && size==1) {
//		System.out.println(i);
//		i++;
//		continue;
//	}
//	else if(i!=1 && size ==2) {
//		Thread.sleep(2000);
//		System.out.println(size);
//	}
//	else break;
//	}