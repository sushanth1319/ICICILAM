package pageObjects;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class URC_Utils extends Base_PO  {
	@FindBy(id = "6")
	public WebElement update;

	@FindBy(id = "12")
	WebElement refresh;

	@FindBy(id = "16")
	WebElement compile;
	
	@FindBy(xpath = "//div[@id='quick-verification-component']/div[3]")
	WebElement text;
	@FindBy(id = "AffinityBusinessRMA")
	WebElement Affinity;
	@FindBy(id="MotorAddOnCoverRMA")
	WebElement motor;
	@FindBy(id = "17")
	WebElement generateADB;

	@FindBy(id = "release_label_id")
	WebElement rel_label;

	@FindBy(id = "elm_file_name")
	WebElement file_name;

	@FindBy(xpath = "//*[@id='yui-gen7']/div[2]/div")
	WebElement path_text_Affinity;
	
	@FindBy(xpath = "//*[@id='yui-gen15']/div[2]/div")
	WebElement path_text_Motor;

	
	public void Affinity_URC() throws InterruptedException {
		
		waitForWebElementAndClick(Affinity);
		waitForWebElementAndClick(update);
		//wait.until(ExpectedConditions.elementToBeClickable(refresh));

		Thread.sleep(100000);

		waitForWebElementAndClick(refresh);
		Thread.sleep(5000);
		//wait.until(ExpectedConditions.elementToBeClickable(compile));

		waitForWebElementAndClick(compile);
		Thread.sleep(10000);

		String[] Error_message = text.getText().split("with");
		String m = Error_message[1];
		String[] q = m.split("error");
		String w = q[0].trim();
		System.out.println(w);
		int error = Integer.parseInt(w);
		if (error > 0) {
			System.out.println("Error!!!");
		} else {
			System.out.println("NO Errors");
		}
	}
	public void Motor_URC() throws InterruptedException {
		
		waitForWebElementAndClick(motor);
		//		update_refresh_compile();
		Thread.sleep(2000);
		waitForWebElementAndClick(update);
		Thread.sleep(450000);
		waitForWebElementAndClick(refresh);
		Thread.sleep(5000);
		waitForWebElementAndClick(compile);
		Thread.sleep(52000);
		String[] Error_message = text.getText().split("with");
		String m = Error_message[1];
		String[] q = m.split("error");
		String w = q[0].trim();
		System.out.println(w);
		int error = Integer.parseInt(w);
		if (error > 0) {
			System.out.println("Error!!!");
		} else {
			System.out.println("NO Errors");
		}
	}
	
	
	
	
	
	
	
	
	
	
	
}
