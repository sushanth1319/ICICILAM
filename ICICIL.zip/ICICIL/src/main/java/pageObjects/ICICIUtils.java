package pageObjects;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class ICICIUtils extends Base_PO{
//	ICICIExcel addExcel;
//	public ICICIUtils(ICICIExcel addExcel) {
//		this.addExcel= addExcel;
//	}
	//TestContext testContext = new TestContext() ;
	@FindBy(xpath = "//a[@title=' Home']")
	WebElement home_btn;
	@FindBy(xpath = "//button[@type='button']")
	WebElement close_btn;
	@FindBy(xpath = "//input[@name='release_label_id']")
	WebElement rel_label;
	@FindBy(xpath = "//input[@name='elm_file_name']")
	WebElement file_name;
	@FindBy(xpath = "//div[@title=' Generate ADB file']")
	WebElement generateADB;
	@FindBy(xpath = "//*[@id='yui-gen7']/div[2]/div")
	WebElement path_text_Cooperate;
	public void label(String fileName,String serverFile) throws InterruptedException {
		String test = fileName;
		String file = serverFile;
		System.out.println(test);
		//sendKeys(rel_label, test);
		sendKeys(rel_label, test);
		Thread.sleep(2000);
		sendKeys(file_name, test+"ADB");
		Thread.sleep(2000);
		waitForWebElementAndClick(By.id("elm_server_selection"));
//		sendKeys(By.id("elm_file_path"), "C:/ICICI/Deployment_78/Liability/PLI_PLNI_PLA_BusinessRMA.server");
		sendKeys(By.id("elm_file_path"), file );
		Thread.sleep(4000);
		waitForWebElementAndClick(By.id("adb_file_generate_btn"));
		Thread.sleep(7000);
	}
	public void ADB1() {
		waitForWebElementAndClick(generateADB);
	}
	public void Path1() throws IOException {
		String loc = getText(path_text_Cooperate);
		String[] pathLoc = loc.split("-");
		String res= pathLoc[1];
		//addExcel.excel(res);
		System.out.println(res);
	}
	public void close1() {
		waitForWebElementAndClick(close_btn);
	}
	public void home1() throws InterruptedException {
		waitForWebElementAndClick(home_btn);
	}
	

}