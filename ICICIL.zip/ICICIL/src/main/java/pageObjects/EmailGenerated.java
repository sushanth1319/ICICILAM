//package pageObjects;
//
//
//	import java.util.Properties;
//
//	import javax.activation.*;
//	import javax.mail.*;
//	import javax.mail.internet.InternetAddress;
//	import javax.mail.internet.MimeBodyPart;
//	import javax.mail.internet.MimeMessage;
//	import javax.mail.internet.MimeMultipart;
//
//	public class EmailGenerated {
//
////	public static void main(String[] args) {
//		public void mail(){
//	    final String username = "sushanth.merugu13@gmail.com";
//	    final String password = "togr hrka lbuo rzog";
//
//	    Properties props = new Properties();
//	    props.put("mail.smtp.auth", true);
//	    props.put("mail.smtp.starttls.enable", true);
//	    props.put("mail.smtp.host", "smtp.gmail.com");
//	    props.put("mail.smtp.port", "587");
//
//	    Session session = Session.getInstance(props,
//	            new javax.mail.Authenticator() {
//	                protected PasswordAuthentication getPasswordAuthentication() {
//	                    return new PasswordAuthentication(username, password);
//	                }
//	            });
//
//	    try {
//
//	        Message message = new MimeMessage(session);
//	        message.setFrom(new InternetAddress("sushanth.merugu13@gmail.com"));
//	        message.setRecipients(Message.RecipientType.TO,
//	                InternetAddress.parse("sushanth.Merugu@valuemomentum.com"));
//	        message.setSubject("Testing Subject");
//	        message.setText("PFA");
//
//	        MimeBodyPart messageBodyPart = new MimeBodyPart();
//
//	        Multipart multipart = new MimeMultipart();
//
//	        messageBodyPart = new MimeBodyPart();
//	        String file = "C:/Users/SushanthMerugu/OneDrive - ValueMomentum, Inc/Documents/ICICILombard/ICICILombardProject/ICICIL/Reports/SparkReport1/Spark.html";
//	        String fileName = "ADBReport";
//	        DataSource source = new FileDataSource(file);
//	        messageBodyPart.setDataHandler(new DataHandler(source));
//	        messageBodyPart.setFileName(fileName);
//	        multipart.addBodyPart(messageBodyPart);
//
//	        message.setContent(multipart);
//
//	        System.out.println("Sending");
//
//	        Transport.send(message);
//
//	        System.out.println("Done");
//
//	    } catch (MessagingException e) {
//	        e.printStackTrace();
//	    }
//	  }
//}
//
