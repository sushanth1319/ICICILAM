//package pageObjects;
//
//
//import java.net.MalformedURLException;
//
//import org.apache.commons.mail.DefaultAuthenticator;
//import org.apache.commons.mail.Email;
//import org.apache.commons.mail.EmailException;
//import org.apache.commons.mail.SimpleEmail;
//
//public class mail {
//
//	//public static void main(String[] args) throws EmailException {
//		
//	public void MailTrigger() throws MalformedURLException, EmailException {
//	
//		Email email = new SimpleEmail();
//		email.setHostName("smtp.gmail.com");
//		email.setSmtpPort(465);
//		email.setAuthenticator(new DefaultAuthenticator("sushanth.merugu13@gmail.com", "togr hrka lbuo rzog"));
//		email.setSSLOnConnect(true);
//		email.setFrom("seleniumbynaresh@gmail.com");
//		email.setSubject("TestMail");
//		email.setMsg("This is a test mail ... :-)");
//		email.addTo("sushanth.merugu@gmail.com");
//		email.send(); 
//		
//	}
//
//}